// Source data from data.js
var tableData = data;

// Get a reference to the table body
var tbody = d3.select("tbody");

// Create function to clear table
function clearTable() {
  tbody.html("");
}

// Create function to populate table with all data
function populateTable() {
  
  // Clear any current data
  clearTable()

  // Loop through data and populate table rows
  tableData.forEach((ufoSighting) => {
    var row = tbody.append("tr");
    Object.entries(ufoSighting).forEach(([key, value]) => {
      var cell = row.append("td");
      cell.text(value);
    });
  });

}

// Initial population of table
populateTable()

// // Select input fields from filter form
// var inputDate = d3.select("#datetime");
// var inputCity = d3.select("#city");
// var inputState = d3.select("#state");
// var inputCountry = d3.select("#country");
// var inputShape = d3.select("#shape");

// Select the buttons
var filterButton = d3.select("#filter-btn");
var resetButton = d3.select("#reset-btn");

// Create event handler for pressing the filter and reset buttons on form
filterButton.on("click", filterTable);
resetButton.on("click", populateTable);


// Create the function to run for filter event
function filterTable() {

    // Prevent the page from refreshing
    d3.event.preventDefault();

    // Clear the table
    clearTable()

    // Get the value of the users inputs and where necessary convert strings to lower case
    var dateValue = d3.select("#datetime").property("value")
    var cityValue = d3.select("#city").property("value").toLowerCase()
    var stateValue = d3.select("#state").property("value").toLowerCase()
    var countryValue = d3.select("#country").property("value").toLowerCase()
    var shapeValue = d3.select("#shape").property("value").toLowerCase()

    // Print the input filter values to the console
    console.log("Inputs:");
    console.log("       Date- " + dateValue);
    console.log("       City- " + cityValue);
    console.log("       State- " + stateValue);
    console.log("       Country- " + countryValue);

    // Create empty array to store filtered data
    filteredData = []

    // Filter data by each input and store returned data into a variable
    if (dateValue.length !== 0) {
    var filteredDate = tableData.filter(tableData => tableData.datetime == dateValue);
      
    if (!filteredData.find(o => o.name === 'tom' && o.text === 'tasty'))
    filteredData.push(filteredDate)
    console.log(filteredDate);
    }

    if (cityValue.length !== 0) {
    var filteredCity = tableData.filter(tableData => tableData.city == cityValue);
    console.log(filteredCity);
    }

    if (stateValue.length !== 0) {
    var filteredState = tableData.filter(tableData => tableData.state == stateValue);
    console.log(filteredState)
    }

    if (countryValue.length !== 0) {
    var filteredCountry = tableData.filter(tableData => tableData.country == countryValue);
    console.log(filteredCountry);
    }

    if (shapeValue.length !== 0) {
    var filteredShape = tableData.filter(tableData => tableData.shape == shapeValue);
    console.log(filteredShape);
    }




  //  // adds an element to the array if it does not already exist using a comparer 
  //   // function
  //   filteredData.prototype.pushIfNotExist = function(element, comparer) { 
  //     if (!this.inArray(comparer)) {
  //         this.push(element);
  //     }
  //   }; 

    // Print filtered data
    console.log(filteredData)




    // Create new table with all filtered data
    filteredData.forEach(ufoSighting => {
      var row = tbody.append("tr");
      Object.entries(ufoSighting).forEach(([key, value]) => {
        var cell = row.append("td");
        cell.text(value);
      });
    });





    // // Check if an element exists in the filteredData array using a comparer function
    // // comparer : function(currentElement)
    // filteredData.prototype.inArray = function(comparer) { 
      
    //   for(var i=0; i < tableData.length; i++) { 
    //       if(comparer(tableData[i])) return true; 
    //   }
    //   return false; 
    // }; 




    // var array = [{ name: "tom", text: "tasty" }];
    // var element = { name: "tom", text: "tasty" };
    // array.pushIfNotExist(element, function(e) { 
    //   return e.name === element.name && e.text === element.text; 
    // });





    // // Push filtered data to the filteredData array
    // filteredData.indexOf(filteredDate) === -1 ? filteredData.push(filteredDate) : console.log("This item already exists");
    // filteredData.indexOf(filteredCity) === -1 ? filteredData.push(filteredCity) : console.log("This item already exists");
    // filteredData.indexOf(filteredState) === -1 ? filteredData.push(filteredState) : console.log("This item already exists");
    // filteredData.indexOf(filteredCountry) === -1 ? filteredData.push(filteredCountry) : console.log("This item already exists");
    // filteredData.indexOf(filteredShape) === -1 ? filteredData.push(filteredShape) : console.log("This item already exists");

    // console.log(filteredData)


    // filteredDate.forEach(filteredSighting => {
    //   var row = tbody.append("tr");
    //   Object.entries(filteredSighting).forEach(([key, value]) => {
    //     var cell = row.append("td");
    //     cell.text(value);
    //   });
    // });
    
    // filteredCity.forEach(filteredSighting => {
    //   var row = tbody.append("tr");
    //   Object.entries(filteredSighting).forEach(([key, value]) => {
    //     var cell = row.append("td");
    //     cell.text(value);
    //   });
    // });
  
    // filteredState.forEach(filteredSighting => {
    //   var row = tbody.append("tr");
    //   Object.entries(filteredSighting).forEach(([key, value]) => {
    //     var cell = row.append("td");
    //     cell.text(value);
    //   });
    // });
  
    // filteredCountry.forEach(filteredSighting => {
    //   var row = tbody.append("tr");
    //   Object.entries(filteredSighting).forEach(([key, value]) => {
    //     var cell = row.append("td");
    //     cell.text(value);
    //   });
    // });
    
    // filteredShape.forEach(filteredSighting => {
    //   var row = tbody.append("tr");
    //   Object.entries(filteredSighting).forEach(([key, value]) => {
    //     var cell = row.append("td");
    //     cell.text(value);
    //   });
    // });

}
